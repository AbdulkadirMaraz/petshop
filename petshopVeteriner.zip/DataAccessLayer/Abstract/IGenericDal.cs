﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer.Concrete;

namespace DataAccessLayer.Abstract
{
    public interface IGenericDal<T> where T : class,new()
    {
        void Insert(T t);
        void Delete(T t);
        void Update(T T);
        List<T> GetList();
        T GetById(int id);
    }
}
