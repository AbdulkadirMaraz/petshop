﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Core;
using BusinessLayer.Abstract;
using DataAccessLayer.Abstract;
using EntityLayer.Concrete;

namespace BusinessLayer.Concrete
{
    public class VeterinarianManager : IVeterinarianService
    {
        IVeterinarianDal _veterinarianDal;

        public VeterinarianManager(IVeterinarianDal veterinarianDal)
        {
            _veterinarianDal = veterinarianDal;
        }

        public void Delete(Veterinarian t)
        {
            _veterinarianDal.Delete(t);
        }

        public Veterinarian GetById(int id)
        {
            return _veterinarianDal.GetById(id);
        }

        public List<Veterinarian> GetList()
        {
            return _veterinarianDal.GetList();
        }

        public void Insert(Veterinarian t)
        {
            _veterinarianDal.Insert(t);
        }

        public void Update(Veterinarian t)
        {
            _veterinarianDal.Update(t);
        }
    }
}
