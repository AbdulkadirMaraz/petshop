﻿using BusinessLayer.Abstract;
using BusinessLayer.FluentValidation;
using EntityLayer.Concrete;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;

namespace AdminPetshopVeteriner.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;
       

        public ProductController(IProductService productService)
        {
            _productService = productService;
            
        }

        public IActionResult Index()
        {
            var values = _productService.GetList();
           
            return View(values);
        }
        [HttpGet]
        public IActionResult AddProduct()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddProduct(Product product)
        {
            ProductValidator validationRules = new();
            ValidationResult result = validationRules.Validate(product);
            if (result.IsValid)
            {
                _productService.Insert(product);
                return RedirectToAction("Index");
            }

            else
            {
                foreach (var item in result.Errors)
                {
                    ModelState.AddModelError(item.PropertyName, item.ErrorMessage);
                }
            }
            return View();
        }
        public IActionResult DeleteProduct(int id)
        {
            var value = _productService.GetById(id);
            _productService.Delete(value);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult EditProduct(int id)
        {
            var value = _productService.GetById(id);
            return View(value);
        }
        [HttpPost]
        public IActionResult EditProduct(Product product)
        {

            ProductValidator validationRules = new();
            ValidationResult result = validationRules.Validate(product);
            if (result.IsValid)
            {
                _productService.Update(product);
                return RedirectToAction("Index");
            }

            else
            {
                foreach (var item in result.Errors)
                {
                    ModelState.AddModelError(item.PropertyName, item.ErrorMessage);
                }
            }
            return View();
        }
    }
}
